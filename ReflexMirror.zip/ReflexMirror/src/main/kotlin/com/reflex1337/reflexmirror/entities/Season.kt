package com.reflex1337.reflexmirror.entities

data class Season(
    val ep: String,
    val id: String,
    val s: String,
    val sele: String
)
